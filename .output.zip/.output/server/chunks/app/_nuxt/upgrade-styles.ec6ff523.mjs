const upgrade_vue_vue_type_style_index_0_scoped_49a783a0_lang = ".title[data-v-49a783a0]{font-size:1.25rem;font-weight:700;line-height:1.75rem}";

const upgradeStyles_ec6ff523 = [upgrade_vue_vue_type_style_index_0_scoped_49a783a0_lang, upgrade_vue_vue_type_style_index_0_scoped_49a783a0_lang];

export { upgradeStyles_ec6ff523 as default };
//# sourceMappingURL=upgrade-styles.ec6ff523.mjs.map
