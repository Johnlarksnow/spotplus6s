const payments_vue_vue_type_style_index_0_lang = "th{text-align:left}td{height:100%;vertical-align:middle}";

const paymentsStyles_904fdd83 = [payments_vue_vue_type_style_index_0_lang, payments_vue_vue_type_style_index_0_lang];

export { paymentsStyles_904fdd83 as default };
//# sourceMappingURL=payments-styles.904fdd83.mjs.map
