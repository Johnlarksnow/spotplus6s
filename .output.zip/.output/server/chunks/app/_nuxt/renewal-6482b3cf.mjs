import { _ as __nuxt_component_0 } from './nuxt-link-563b35af.mjs';
import { _ as _sfc_main$1 } from './Alert-19350b7d.mjs';
import { a as countryList } from './utils-a6f78e75.mjs';
import { useSSRContext, defineComponent, reactive, ref, mergeProps, unref, withCtx, createTextVNode, toDisplayString } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import 'ufo';
import '../server.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'h3';
import 'destr';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'framesync';
import 'popmotion';
import 'style-value-types';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "renewal",
  __ssrInlineRender: true,
  setup(__props) {
    const formData = reactive({
      key: "",
      email: "",
      newEmail: "",
      password: "",
      newPassword: "",
      country: "select-a-country"
    });
    const alertMessage = ref("");
    const alertType = ref("");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_alert = _sfc_main$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex md:flex-row flex-col-reverse w-full md:gap-8 gap-3 h-full justify-center items-center" }, _attrs))} data-v-495698af><div class="flex gap-2 flex-col w-full md:w-96 items-start justify-center" data-v-495698af><h1 class="text-2xl font-bold" data-v-495698af> Renew your account </h1><form class="flex flex-col gap-2 w-full" data-v-495698af><input${ssrRenderAttr("value", formData.key)} type="text" placeholder="Enter your renewal key" class="input" required data-v-495698af><input${ssrRenderAttr("value", formData.email)} type="email" placeholder="Enter old account email" class="input" required data-v-495698af><input${ssrRenderAttr("value", formData.newEmail)} type="email" placeholder="Enter new account email" class="input" required data-v-495698af><input${ssrRenderAttr("value", formData.password)} type="password" placeholder="Enter old account password" class="input" required data-v-495698af><input${ssrRenderAttr("value", formData.newPassword)} type="password" placeholder="Enter new account password" class="input" required data-v-495698af><select name="countries" class="input" required placeholder="Select a country" data-v-495698af><!--[-->`);
      ssrRenderList("countryList" in _ctx ? _ctx.countryList : unref(countryList), (country) => {
        _push(`<option${ssrRenderAttr("value", country.value)} data-v-495698af>${ssrInterpolate(country.name)}</option>`);
      });
      _push(`<!--]--></select><button type="submit" class="bg-green-900 mt-2 text-white rounded-lg py-2 px-4" data-v-495698af> Renew </button></form>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/#pricing",
        class: "text-green-500 hover:text-green-400 transition-all"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` I don&#39;t have a renewal key `);
          } else {
            return [
              createTextVNode(" I don't have a renewal key ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="md:w-2/6 space-y-1" data-v-495698af><h3 class="title" data-v-495698af> Is my data safe with Spotigrade? </h3><p class="" data-v-495698af> Yes, of course. We do not save your Spotify login. Our bot will only login to your account for upgrading/renewing your account. </p><h3 class="title" data-v-495698af> What happens if I get kicked? </h3><p data-v-495698af> Nothing! You can renew your account automatically anytime with our automated system. There&#39;s no hassle for you working with us. </p><h3 class="title" data-v-495698af> How does the renewal work? </h3><p data-v-495698af> First, we validate your renewal key and current account details. Secondly, we update your account&#39;s email and password. Lastly, our bot proceeds to renew your account automatically. </p></div>`);
      if (alertMessage.value) {
        _push(ssrRenderComponent(_component_alert, {
          type: alertType.value,
          message: alertMessage.value,
          onClose: ($event) => alertMessage.value = ""
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(alertMessage.value)}`);
            } else {
              return [
                createTextVNode(toDisplayString(alertMessage.value), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/renewal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const renewal = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-495698af"]]);

export { renewal as default };
//# sourceMappingURL=renewal-6482b3cf.mjs.map
