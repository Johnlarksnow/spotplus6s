const login_vue_vue_type_style_index_0_lang = ".input{--tw-border-opacity:1;--tw-bg-opacity:1;background-color:#181818;background-color:rgb(24 24 24/var(--tw-bg-opacity));border-bottom-width:2px;border-color:#27272a;border-color:rgb(39 39 42/var(--tw-border-opacity));font-size:1.125rem;line-height:1.75rem;padding:.5rem;width:100%}.input:focus{outline:2px solid transparent;outline-offset:2px}";

const loginStyles_db57d3a5 = [login_vue_vue_type_style_index_0_lang, login_vue_vue_type_style_index_0_lang];

export { loginStyles_db57d3a5 as default };
//# sourceMappingURL=login-styles.db57d3a5.mjs.map
