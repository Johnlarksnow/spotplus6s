const Icon_vue_vue_type_style_index_0_scoped_c3ad5561_lang = ".icon[data-v-c3ad5561]{display:inline-block;vertical-align:middle}";

const IconStyles_31d27e7d = [Icon_vue_vue_type_style_index_0_scoped_c3ad5561_lang, Icon_vue_vue_type_style_index_0_scoped_c3ad5561_lang];

export { IconStyles_31d27e7d as default };
//# sourceMappingURL=Icon-styles.31d27e7d.mjs.map
