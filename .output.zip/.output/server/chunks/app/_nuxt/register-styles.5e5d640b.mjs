const register_vue_vue_type_style_index_0_lang = ".slide-enter-active{transition-duration:.3s;transition-timing-function:ease-in}.slide-leave-active{transition-duration:.3s;transition-timing-function:cubic-bezier(0,1,.5,1)}.slide-enter-to,.slide-leave{max-height:100px;overflow:hidden}.slide-enter,.slide-leave-to{max-height:0;overflow:hidden}";

const registerStyles_5e5d640b = [register_vue_vue_type_style_index_0_lang, register_vue_vue_type_style_index_0_lang];

export { registerStyles_5e5d640b as default };
//# sourceMappingURL=register-styles.5e5d640b.mjs.map
