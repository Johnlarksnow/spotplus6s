const renewal_vue_vue_type_style_index_0_scoped_495698af_lang = ".title[data-v-495698af]{font-size:1.25rem;font-weight:700;line-height:1.75rem}";

const renewalStyles_7a1b5a69 = [renewal_vue_vue_type_style_index_0_scoped_495698af_lang, renewal_vue_vue_type_style_index_0_scoped_495698af_lang];

export { renewalStyles_7a1b5a69 as default };
//# sourceMappingURL=renewal-styles.7a1b5a69.mjs.map
