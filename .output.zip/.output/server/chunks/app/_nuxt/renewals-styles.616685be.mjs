const renewals_vue_vue_type_style_index_0_lang = "th{text-align:left}td{height:100%;vertical-align:middle}";

const renewalsStyles_616685be = [renewals_vue_vue_type_style_index_0_lang, renewals_vue_vue_type_style_index_0_lang];

export { renewalsStyles_616685be as default };
//# sourceMappingURL=renewals-styles.616685be.mjs.map
