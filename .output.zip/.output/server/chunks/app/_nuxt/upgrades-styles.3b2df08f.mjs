const upgrades_vue_vue_type_style_index_0_lang = "th{text-align:left}td{height:100%;vertical-align:middle}";

const upgradesStyles_3b2df08f = [upgrades_vue_vue_type_style_index_0_lang, upgrades_vue_vue_type_style_index_0_lang];

export { upgradesStyles_3b2df08f as default };
//# sourceMappingURL=upgrades-styles.3b2df08f.mjs.map
