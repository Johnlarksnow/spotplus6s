const client_manifest = {
  "Up.css": {
    "resourceType": "style",
    "file": "Up.d91b3ff3.css",
    "src": "Up.css"
  },
  "_Alert.vue.ebf23dab.js": {
    "resourceType": "script",
    "module": true,
    "file": "Alert.vue.ebf23dab.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_Loader.a4986e74.js": {
    "resourceType": "script",
    "module": true,
    "file": "Loader.a4986e74.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "__plugin-vue_export-helper.c27b6911.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_Up.vue.74bc8844.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "spotifylogo.fd8558d5.png"
    ],
    "css": [
      "Up.d91b3ff3.css"
    ],
    "file": "Up.vue.74bc8844.js",
    "imports": [
      "_nuxt-link.2cd8eefb.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1ff47caa.js",
      "_config.20f1627f.js",
      "_store.638402e2.js"
    ]
  },
  "Up.d91b3ff3.css": {
    "file": "Up.d91b3ff3.css",
    "resourceType": "style"
  },
  "spotifylogo.fd8558d5.png": {
    "file": "spotifylogo.fd8558d5.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "__plugin-vue_export-helper.c27b6911.js": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.c27b6911.js"
  },
  "_buy.70a900d3.js": {
    "resourceType": "script",
    "module": true,
    "file": "buy.70a900d3.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_store.638402e2.js",
      "_fetch.1ff47caa.js"
    ]
  },
  "_client-only.0fb5fc7f.js": {
    "resourceType": "script",
    "module": true,
    "file": "client-only.0fb5fc7f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_config.20f1627f.js": {
    "resourceType": "script",
    "module": true,
    "file": "config.20f1627f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_fetch.1ff47caa.js": {
    "resourceType": "script",
    "module": true,
    "file": "fetch.1ff47caa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.2cd8eefb.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.2cd8eefb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_store.638402e2.js": {
    "resourceType": "script",
    "module": true,
    "file": "store.638402e2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_utils.f07451bf.js": {
    "resourceType": "script",
    "module": true,
    "file": "utils.f07451bf.js"
  },
  "components/img/spotifylogo.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "spotifylogo.fd8558d5.png",
    "src": "components/img/spotifylogo.png"
  },
  "layouts/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "file": "checkout.e3d2342c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/checkout.vue"
  },
  "layouts/dash.vue": {
    "resourceType": "script",
    "module": true,
    "file": "dash.9661e2e7.js",
    "imports": [
      "_Up.vue.74bc8844.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.2cd8eefb.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.20f1627f.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_fetch.1ff47caa.js",
      "_store.638402e2.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/dash.vue"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.bb04b643.js",
    "imports": [
      "_Up.vue.74bc8844.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.2cd8eefb.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.20f1627f.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_fetch.1ff47caa.js",
      "_store.638402e2.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "middleware/auth.ts": {
    "resourceType": "script",
    "module": true,
    "file": "auth.4564fa4e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_store.638402e2.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth.ts"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.8bdbaeb8.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.f2904feb.js",
    "imports": [
      "_nuxt-link.2cd8eefb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.8bdbaeb8.css": {
    "file": "error-404.8bdbaeb8.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.b63a96f5.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.93e34ab4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.b63a96f5.css": {
    "file": "error-500.b63a96f5.css",
    "resourceType": "style"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "file": "Icon.31621e1e.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "Icon.ea517fb1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.20f1627f.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.31621e1e.css": {
    "file": "Icon.31621e1e.css",
    "resourceType": "style"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "file": "IconCSS.6edc7bff.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "IconCSS.d0244d9d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.20f1627f.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.6edc7bff.css": {
    "file": "IconCSS.6edc7bff.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.7febcf90.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.7febcf90.css"
    ],
    "dynamicImports": [
      "middleware/auth.ts",
      "layouts/checkout.vue",
      "layouts/dash.vue",
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.fad62010.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.7febcf90.css": {
    "file": "entry.7febcf90.css",
    "resourceType": "style"
  },
  "pages/checkout/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.4ae9ae44.js",
    "imports": [
      "_nuxt-link.2cd8eefb.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1ff47caa.js",
      "_store.638402e2.js",
      "_config.20f1627f.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/checkout/[id].vue"
  },
  "pages/dashboard/index.css": {
    "resourceType": "style",
    "file": "index.a7d58b26.css",
    "src": "pages/dashboard/index.css"
  },
  "pages/dashboard/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.5fa1f332.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_client-only.0fb5fc7f.js",
      "_store.638402e2.js",
      "_fetch.1ff47caa.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/dashboard/index.vue"
  },
  "index.a7d58b26.css": {
    "file": "index.a7d58b26.css",
    "resourceType": "style"
  },
  "slick.7e3cb8f6.css": {
    "file": "slick.7e3cb8f6.css",
    "resourceType": "style"
  },
  "pages/dashboard/index/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.e5b42064.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_nuxt-link.2cd8eefb.js",
      "_buy.70a900d3.js",
      "_store.638402e2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.20f1627f.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_fetch.1ff47caa.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/dashboard/index/index.vue"
  },
  "pages/dashboard/index/payments.css": {
    "resourceType": "style",
    "file": "payments.d863ffc1.css",
    "src": "pages/dashboard/index/upgrades.css"
  },
  "pages/dashboard/index/payments.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "payments.40ab05e8.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Loader.a4986e74.js",
      "_nuxt-link.2cd8eefb.js",
      "_store.638402e2.js",
      "_fetch.1ff47caa.js",
      "_utils.f07451bf.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.20f1627f.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/dashboard/index/payments.vue"
  },
  "payments.d863ffc1.css": {
    "file": "payments.d863ffc1.css",
    "resourceType": "style"
  },
  "pages/dashboard/index/renewals.css": {
    "resourceType": "style",
    "file": "payments.d863ffc1.css",
    "src": "pages/dashboard/index/upgrades.css"
  },
  "pages/dashboard/index/renewals.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "renewals.fe29c823.js",
    "imports": [
      "_Loader.a4986e74.js",
      "_store.638402e2.js",
      "_fetch.1ff47caa.js",
      "_utils.f07451bf.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.20f1627f.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/dashboard/index/renewals.vue"
  },
  "pages/dashboard/index/upgrades.css": {
    "resourceType": "style",
    "file": "payments.d863ffc1.css",
    "src": "pages/dashboard/index/upgrades.css"
  },
  "pages/dashboard/index/upgrades.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "upgrades.d0a972db.js",
    "imports": [
      "_Loader.a4986e74.js",
      "_store.638402e2.js",
      "_fetch.1ff47caa.js",
      "_utils.f07451bf.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.20f1627f.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/dashboard/index/upgrades.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.b56c5111.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.8d32a67e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_nuxt-link.2cd8eefb.js",
      "_buy.70a900d3.js",
      "_store.638402e2.js",
      "_client-only.0fb5fc7f.js",
      "_config.20f1627f.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_fetch.1ff47caa.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.b56c5111.css": {
    "file": "index.b56c5111.css",
    "resourceType": "style"
  },
  "pages/login.css": {
    "resourceType": "style",
    "file": "login.feb0ee24.css",
    "src": "pages/login.css"
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "login.79d3de51.js",
    "imports": [
      "_nuxt-link.2cd8eefb.js",
      "_Alert.vue.ebf23dab.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1ff47caa.js",
      "_store.638402e2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/login.vue"
  },
  "login.feb0ee24.css": {
    "file": "login.feb0ee24.css",
    "resourceType": "style"
  },
  "pages/register.css": {
    "resourceType": "style",
    "file": "register.23b2738f.css",
    "src": "pages/register.css"
  },
  "pages/register.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "register.f53290cd.js",
    "imports": [
      "_nuxt-link.2cd8eefb.js",
      "_Alert.vue.ebf23dab.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1ff47caa.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/register.vue"
  },
  "register.23b2738f.css": {
    "file": "register.23b2738f.css",
    "resourceType": "style"
  },
  "pages/renewal.css": {
    "resourceType": "style",
    "file": "renewal.2281fec4.css",
    "src": "pages/renewal.css"
  },
  "pages/renewal.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "renewal.2e3f8783.js",
    "imports": [
      "_nuxt-link.2cd8eefb.js",
      "_Alert.vue.ebf23dab.js",
      "_utils.f07451bf.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/renewal.vue"
  },
  "renewal.2281fec4.css": {
    "file": "renewal.2281fec4.css",
    "resourceType": "style"
  },
  "pages/upgrade.css": {
    "resourceType": "style",
    "file": "upgrade.6ee4935d.css",
    "src": "pages/upgrade.css"
  },
  "pages/upgrade.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "upgrade.41f50df9.js",
    "imports": [
      "_nuxt-link.2cd8eefb.js",
      "_Alert.vue.ebf23dab.js",
      "_utils.f07451bf.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/upgrade.vue"
  },
  "upgrade.6ee4935d.css": {
    "file": "upgrade.6ee4935d.css",
    "resourceType": "style"
  },
  "slick.css": {
    "resourceType": "style",
    "file": "slick.7e3cb8f6.css",
    "src": "slick.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
